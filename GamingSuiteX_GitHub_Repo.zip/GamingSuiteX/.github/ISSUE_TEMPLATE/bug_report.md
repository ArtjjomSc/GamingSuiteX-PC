---
name: Fehler melden
about: Etwas funktioniert nicht wie erwartet
title: "[Fehler] "
labels: bug
---

**Was ist passiert?**
<!-- Kurz beschreiben, z. B. "Messung bei Valorant bricht nach 3 Sekunden ab" -->

**Was hast du erwartet?**

**Schritte zum Nachstellen**
1.
2.

**Fehlerbericht**
<!-- Settings -> "Fehlerbericht erstellen" -> die ZIP-Datei vom Desktop hier hineinziehen -->

**Screenshot** (optional)

**Hardware** (falls kein Fehlerbericht möglich)
- Windows-Version:
- CPU:
- Grafikkarte:
- GamingSuite-X-Version:
